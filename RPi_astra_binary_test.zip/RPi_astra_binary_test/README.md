RPi Astra Binary Test
=====================

Run from inside this folder on the Raspberry Pi:

```bash
python Kraken_Binaries/render_integer_slp_video.py --no-live --no-video
```

For MP4 rendering instead of prediction-only:

```bash
python Kraken_Binaries/render_integer_slp_video.py --no-live
```

The script defaults to the included Day 4 Flight 3 matched CSV and the included
`astra_binaries_future200ms` quantized parameters.
